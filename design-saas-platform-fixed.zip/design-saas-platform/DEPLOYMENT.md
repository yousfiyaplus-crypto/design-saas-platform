# Deploying to a VPS (DigitalOcean Droplet / AWS EC2)

Target: Ubuntu 22.04 LTS, 2 vCPU / 4GB RAM minimum (GPT-4o calls and
Next.js builds are memory-hungry; 2GB will swap under load).

## 1. Provision the server

- DigitalOcean: create a Droplet → Ubuntu 22.04 → at least the
  `s-2vcpu-4gb` size → add your SSH key at creation.
- AWS EC2: launch a `t3.medium` instance → Ubuntu 22.04 AMI → attach a
  security group allowing inbound 22 (SSH), 80 (HTTP), 443 (HTTPS).

SSH in:

    ssh root@your-server-ip

## 2. Install Docker and Docker Compose

    apt-get update
    apt-get install -y ca-certificates curl gnupg

    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
    chmod a+r /etc/apt/keyrings/docker.asc

    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
      $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
      tee /etc/apt/sources.list.d/docker.list > /dev/null

    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

    docker --version
    docker compose version

## 3. Create a non-root deploy user (recommended)

    adduser deploy
    usermod -aG docker deploy
    su - deploy

Run everything below as `deploy`, not `root`.

## 4. Pull the code

    git clone https://github.com/your-org/design-saas-platform.git
    cd design-saas-platform

For private repos, use a deploy key or a personal access token:

    git clone https://<token>@github.com/your-org/design-saas-platform.git

## 5. Set up the `.env` file

    cp .env.example .env
    nano .env

Fill in every value. Generate the encryption key locally first (not on
the server, to avoid leaving it in shell history on a shared box):

    node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

Paste the result into `ENCRYPTION_KEY`. Fill in Supabase, OpenAI, Figma,
Vercel, and Stripe credentials from each provider's dashboard.

Lock down the file permissions:

    chmod 600 .env

## 6. Build the containers

    docker compose build

This runs the full multi-stage Dockerfile build. Expect several minutes
on first build; subsequent builds are faster due to layer caching
(the `deps` stage only re-runs if `package.json`/`package-lock.json`
changed).

## 7. Run the database migration

Migrations must run before the app container starts serving traffic
against a fresh database. Run them as a one-off container using the
already-built app image, rather than baking `migrate deploy` into the
Dockerfile's CMD (migrations should never run automatically on every
container restart — only deliberately, once, per deploy):

    docker compose run --rm app npx prisma migrate deploy

Verify the migration applied cleanly:

    docker compose run --rm app npx prisma migrate status

## 8. Start the stack

    docker compose up -d

Check everything is healthy:

    docker compose ps
    docker compose logs -f app

You should see Next.js's standalone server log `Listening on port 3000`.

## 9. Put Nginx + TLS in front (recommended, not optional for production)

The app container listens on `3000` internally. Don't expose it directly
to the internet — terminate TLS with Nginx + Let's Encrypt in front.

    apt-get install -y nginx certbot python3-certbot-nginx

Create `/etc/nginx/sites-available/design-saas`:

    server {
        listen 80;
        server_name yourdomain.com;

        location / {
            proxy_pass http://127.0.0.1:3000;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }
    }

Enable it and get a certificate:

    ln -s /etc/nginx/sites-available/design-saas /etc/nginx/sites-enabled/
    nginx -t
    systemctl reload nginx
    certbot --nginx -d yourdomain.com

Certbot auto-configures the HTTPS redirect and sets up renewal via a
systemd timer — verify with:

    systemctl status certbot.timer

## 10. Configure webhook endpoints with external providers

Once the domain is live over HTTPS, register the following with each
provider (these cannot point at an IP address or `localhost`):

- **Stripe**: Dashboard → Developers → Webhooks → add endpoint
  `https://yourdomain.com/api/stripe/webhook`, subscribe to
  `checkout.session.completed`, `customer.subscription.updated`,
  `customer.subscription.deleted`.
- **Figma**: handled per-user via OAuth + the `/api/figma/webhook`
  route registering a webhook per connected file (done in-app, not a
  one-time global config).

## 11. Redeploying after code changes

    cd design-saas-platform
    git pull origin main
    docker compose build app
    docker compose run --rm app npx prisma migrate deploy
    docker compose up -d app

This rebuilds only the `app` service, runs any new migrations, and
restarts the container with zero changes to `postgres`/`redis` data
volumes.

## 12. Backups

Postgres data lives in the `postgres-data` named volume. Back it up
with periodic `pg_dump`, not raw volume copies (safer across Postgres
version changes):

    docker compose exec postgres pg_dump -U postgres design_saas > backup-$(date +%F).sql

Automate this with a cron job on the host and ship backups off-box
(S3, DigitalOcean Spaces, etc.) — a VPS disk failure should not be a
data-loss event.

## 13. Monitoring basics

At minimum:

    docker compose logs -f app       # application logs
    docker stats                     # live resource usage

For anything beyond ad-hoc checks, ship `docker compose logs` output to
a log aggregator (e.g. Grafana Loki, Datadog agent) rather than relying
on SSH + `docker logs` during an incident.
