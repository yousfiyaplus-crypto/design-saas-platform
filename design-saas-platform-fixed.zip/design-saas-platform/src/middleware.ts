import { NextResponse, type NextRequest } from 'next/server';
import { createServerClient, type CookieOptions } from '@supabase/ssr';

/**
 * Edge middleware:
 *  - Refreshes the Supabase session cookie on every request (standard
 *    Supabase SSR pattern).
 *  - For /api/** routes (excluding /api/webhooks/**, which are authenticated
 *    via provider signatures, not user JWTs), validates the user's JWT and
 *    forwards the verified userId to the route handler via a request header.
 *  - Unauthenticated requests to protected /api routes get a 401 before
 *    they ever reach the route handler.
 */

const PUBLIC_API_PREFIXES = ['/api/webhooks', '/api/stripe/webhook', '/api/figma/webhook'];

function isPublicApiRoute(pathname: string): boolean {
  return PUBLIC_API_PREFIXES.some((prefix) => pathname.startsWith(prefix));
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  let response = NextResponse.next({
    request: { headers: request.headers },
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          request.cookies.set({ name, value, ...options });
          response = NextResponse.next({
            request: { headers: request.headers },
          });
          response.cookies.set({ name, value, ...options });
        },
        remove(name: string, options: CookieOptions) {
          request.cookies.set({ name, value: '', ...options });
          response = NextResponse.next({
            request: { headers: request.headers },
          });
          response.cookies.set({ name, value: '', ...options });
        },
      },
    }
  );

  // Always touch getUser() so Supabase can refresh expired access tokens
  // and rewrite the session cookies on `response`.
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  // Only enforce auth on /api/** routes. Page routes handle their own
  // redirect-to-login logic in layout/server components.
  if (!pathname.startsWith('/api')) {
    return response;
  }

  if (isPublicApiRoute(pathname)) {
    return response;
  }

  if (error || !user) {
    return NextResponse.json(
      { error: 'Unauthorized', message: 'A valid session is required.' },
      { status: 401 }
    );
  }

  // Forward the verified user id to API route handlers. Route handlers
  // must read this header rather than trusting any client-supplied userId.
  const forwardedHeaders = new Headers(request.headers);
  forwardedHeaders.set('x-user-id', user.id);
  forwardedHeaders.set('x-user-email', user.email ?? '');

  response = NextResponse.next({
    request: { headers: forwardedHeaders },
  });

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths except static assets, images, and favicon.
     * Page routes still pass through (for the session-refresh side effect)
     * but only /api/** triggers the auth check above.
     */
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
