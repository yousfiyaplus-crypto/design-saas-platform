import { Toaster } from '@/components/ui/toaster';
import './globals.css';

export const metadata = {
  title: 'Design Platform',
  description: 'Generate, sync, and deploy on-brand UI components.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
