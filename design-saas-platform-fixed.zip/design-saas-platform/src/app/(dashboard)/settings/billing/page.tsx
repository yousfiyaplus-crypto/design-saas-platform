'use client';

import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/components/ui/use-toast';

const FREE_TIER_MONTHLY_LIMIT = 3;

interface BillingInfo {
  plan: 'FREE' | 'PRO';
  generationsThisMonth: number;
  usageResetAt: string;
  subscription: {
    status: string;
    currentPeriodEnd: string;
    cancelAtPeriodEnd: boolean;
  } | null;
}

export default function BillingPage() {
  const { toast } = useToast();
  const [billing, setBilling] = useState<BillingInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  useEffect(() => {
    fetch('/api/billing')
      .then((res) => res.json())
      .then((data) => setBilling(data.billing))
      .catch(() =>
        toast({ variant: 'destructive', title: 'Could not load billing info' })
      )
      .finally(() => setIsLoading(false));
  }, [toast]);

  async function handleUpgrade() {
    setIsCheckingOut(true);
    try {
      const res = await fetch('/api/stripe/checkout', { method: 'POST' });
      const data = await res.json();
      if (!res.ok || !data.url) throw new Error(data?.error ?? 'Checkout failed.');
      window.location.href = data.url;
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Checkout failed',
        description: err instanceof Error ? err.message : 'Please try again.',
      });
      setIsCheckingOut(false);
    }
  }

  if (isLoading) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-10">
        <Skeleton className="h-40 w-full rounded-xl" />
      </div>
    );
  }

  if (!billing) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-10 text-sm text-muted-foreground">
        Could not load billing information.
      </div>
    );
  }

  const isPro = billing.plan === 'PRO';

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <h1 className="mb-6 text-2xl font-semibold tracking-tight">Billing</h1>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2">
              Current plan
              <Badge variant={isPro ? 'default' : 'secondary'}>{billing.plan}</Badge>
            </CardTitle>
            <CardDescription className="mt-1">
              {isPro
                ? 'Unlimited component generations.'
                : `${billing.generationsThisMonth} / ${FREE_TIER_MONTHLY_LIMIT} generations used this month.`}
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          {billing.subscription?.cancelAtPeriodEnd && (
            <p className="text-sm text-muted-foreground">
              Your subscription will end on{' '}
              {new Date(billing.subscription.currentPeriodEnd).toLocaleDateString()}.
            </p>
          )}
        </CardContent>
        {!isPro && (
          <CardFooter>
            <Button onClick={handleUpgrade} disabled={isCheckingOut}>
              {isCheckingOut ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Upgrade to Pro — $15/mo'}
            </Button>
          </CardFooter>
        )}
      </Card>
    </div>
  );
}
