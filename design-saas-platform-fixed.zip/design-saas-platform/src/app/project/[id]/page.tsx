'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Editor, { OnMount } from '@monaco-editor/react';
import {
  SandpackProvider,
  SandpackPreview,
  SandpackLayout,
} from '@codesandbox/sandpack-react';
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from '@/components/ui/resizable';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import {
  ArrowLeft,
  Sparkles,
  Rocket,
  Loader2,
  ExternalLink,
  RefreshCw,
} from 'lucide-react';

interface ComponentRecord {
  id: string;
  name: string;
  code: string;
  framework: 'REACT' | 'VUE';
  createdAt: string;
}

interface ProjectDetail {
  id: string;
  name: string;
  sourceUrl: string | null;
  vercelProjectId: string | null;
  designTokens: {
    colors: string[];
    fonts: string[];
    radii: Record<string, string>;
  } | null;
  components: ComponentRecord[];
  deployments: Array<{ id: string; url: string | null; status: string }>;
}

const DEFAULT_SCAFFOLD_CODE = `export default function GeneratedComponent() {
  return (
    <div className="flex min-h-[300px] items-center justify-center p-8">
      <p className="text-slate-400">
        Describe a component in the prompt panel to get started.
      </p>
    </div>
  );
}
`;

export default function ProjectEditorPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { toast } = useToast();

  const [project, setProject] = useState<ProjectDetail | null>(null);
  const [isLoadingProject, setIsLoadingProject] = useState(true);

  const [activeComponentId, setActiveComponentId] = useState<string | null>(null);
  const [code, setCode] = useState(DEFAULT_SCAFFOLD_CODE);
  const [prompt, setPrompt] = useState('');

  const [isGenerating, setIsGenerating] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [hasEverDeployed, setHasEverDeployed] = useState(false);
  const [lastDeploymentUrl, setLastDeploymentUrl] = useState<string | null>(null);

  const editorRef = useRef<Parameters<OnMount>[0] | null>(null);

  useEffect(() => {
    fetchProject();
  }, [params.id]);

  async function fetchProject() {
    setIsLoadingProject(true);
    try {
      const res = await fetch(`/api/projects/${params.id}`);
      if (!res.ok) throw new Error('Failed to load project.');
      const data = await res.json();
      const p: ProjectDetail = data.project;

      setProject(p);
      setHasEverDeployed(Boolean(p.vercelProjectId));
      setLastDeploymentUrl(p.deployments[0]?.url ?? null);

      if (p.components.length > 0) {
        setActiveComponentId(p.components[0].id);
        setCode(p.components[0].code);
      }
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Could not load project',
        description: err instanceof Error ? err.message : 'Unknown error.',
      });
    } finally {
      setIsLoadingProject(false);
    }
  }

  const handleEditorMount: OnMount = (editor) => {
    editorRef.current = editor;
  };

  const handleGenerate = useCallback(async () => {
    if (!project) return;
    if (prompt.trim().length < 10) {
      toast({
        variant: 'destructive',
        title: 'Prompt too short',
        description: 'Describe the component in at least 10 characters.',
      });
      return;
    }

    setIsGenerating(true);
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          framework: 'react',
          projectId: project.id,
          designTokens: project.designTokens
            ? {
                colors: {
                  primary: project.designTokens.colors[0],
                  secondary: project.designTokens.colors[1],
                },
                fonts: { body: project.designTokens.fonts[0] },
                radii: { md: project.designTokens.radii?.default },
              }
            : undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data?.message ?? 'Generation failed.');
      }

      setCode(data.code);
      setActiveComponentId(data.id);

      toast({
        title: data.cached ? 'Component ready (cached)' : 'Component generated',
        description: data.explanation,
      });

      // Refresh component list in the background so the tab bar updates.
      fetchProject();
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Generation failed',
        description: err instanceof Error ? err.message : 'Unknown error.',
      });
    } finally {
      setIsGenerating(false);
    }
  }, [project, prompt, toast]);

  const handleDeploy = useCallback(async () => {
    if (!project) return;

    setIsDeploying(true);
    try {
      const res = await fetch('/api/deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: project.id,
          ...(activeComponentId ? { componentId: activeComponentId } : { code }),
          target: 'production',
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data?.message ?? 'Deployment failed.');
      }

      setHasEverDeployed(true);
      setLastDeploymentUrl(data.deploymentUrl);

      toast({
        title: data.isRedeploy ? 'Live site updated' : 'Deployed successfully',
        description: (
          <a
            href={data.deploymentUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 underline"
          >
            {data.deploymentUrl}
            <ExternalLink className="h-3 w-3" />
          </a>
        ),
      });
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Deployment failed',
        description: err instanceof Error ? err.message : 'Unknown error.',
      });
    } finally {
      setIsDeploying(false);
    }
  }, [project, activeComponentId, code, toast]);

  if (isLoadingProject) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex h-screen flex-col items-center justify-center gap-4">
        <p className="text-muted-foreground">Project not found.</p>
        <Button variant="outline" onClick={() => router.push('/dashboard')}>
          Back to Dashboard
        </Button>
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col">
      {/* Header */}
      <header className="flex items-center justify-between border-b px-4 py-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.push('/dashboard')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-sm font-semibold leading-none">{project.name}</h1>
            {project.sourceUrl && (
              <p className="mt-1 text-xs text-muted-foreground">{project.sourceUrl}</p>
            )}
          </div>
          {lastDeploymentUrl && (
            <Badge variant="secondary" className="ml-2 gap-1">
              <a
                href={lastDeploymentUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1"
              >
                Live <ExternalLink className="h-3 w-3" />
              </a>
            </Badge>
          )}
        </div>

        <Button onClick={handleDeploy} disabled={isDeploying}>
          {isDeploying ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {hasEverDeployed ? 'Updating...' : 'Deploying...'}
            </>
          ) : hasEverDeployed ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4" />
              Update Live Site
            </>
          ) : (
            <>
              <Rocket className="mr-2 h-4 w-4" />
              Deploy
            </>
          )}
        </Button>
      </header>

      {/* Component tabs */}
      {project.components.length > 0 && (
        <div className="border-b px-4 py-2">
          <Tabs
            value={activeComponentId ?? undefined}
            onValueChange={(id) => {
              const comp = project.components.find((c) => c.id === id);
              if (comp) {
                setActiveComponentId(comp.id);
                setCode(comp.code);
              }
            }}
          >
            <TabsList>
              {project.components.map((c) => (
                <TabsTrigger key={c.id} value={c.id} className="max-w-[160px] truncate">
                  {c.name}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>
      )}

      {/* Main split view */}
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          <ResizablePanel defaultSize={50} minSize={30}>
            <div className="flex h-full flex-col">
              <div className="border-b p-3">
                <div className="flex gap-2">
                  <Textarea
                    placeholder="Describe the component you want (e.g. 'A pricing card with a highlighted Pro tier and a CTA button')"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="min-h-[60px] resize-none text-sm"
                  />
                  <Button
                    onClick={handleGenerate}
                    disabled={isGenerating}
                    className="shrink-0 self-end"
                  >
                    {isGenerating ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Sparkles className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="flex-1">
                <Editor
                  height="100%"
                  defaultLanguage="typescript"
                  theme="vs-dark"
                  value={code}
                  onChange={(value) => setCode(value ?? '')}
                  onMount={handleEditorMount}
                  options={{
                    minimap: { enabled: false },
                    fontSize: 13,
                    wordWrap: 'on',
                    scrollBeyondLastLine: false,
                    automaticLayout: true,
                  }}
                />
              </div>
            </div>
          </ResizablePanel>

          <ResizableHandle withHandle />

          <ResizablePanel defaultSize={50} minSize={30}>
            <div className="h-full">
              <SandpackProvider
                template="react-ts"
                theme="light"
                files={{
                  '/App.tsx': code,
                  '/styles.css': `@tailwind base;\n@tailwind components;\n@tailwind utilities;\n`,
                }}
                customSetup={{
                  dependencies: {
                    react: '^18.3.1',
                    'react-dom': '^18.3.1',
                  },
                }}
                options={{
                  externalResources: ['https://cdn.tailwindcss.com'],
                }}
              >
                <SandpackLayout style={{ height: '100%', border: 'none' }}>
                  <SandpackPreview
                    style={{ height: '100%' }}
                    showNavigator={false}
                    showRefreshButton={true}
                    showOpenInCodeSandbox={false}
                  />
                </SandpackLayout>
              </SandpackProvider>
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </div>
  );
}
