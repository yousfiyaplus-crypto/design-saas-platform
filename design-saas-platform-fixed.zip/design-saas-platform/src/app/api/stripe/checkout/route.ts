import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { prisma } from '@/lib/prisma';
import { getUserIdOrThrow, unauthorizedResponse } from '@/lib/auth/getUserId';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-04-10',
});

export async function POST(req: NextRequest) {
  try {
    const userId = getUserIdOrThrow();
    const user = await prisma.user.findUnique({ where: { id: userId } });

    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    // إذا كان عنده حساب Stripe سابق، نستخدمه، وإلا ننشئ واحد
    let customerId = user.stripeCustomerId;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        metadata: { userId: user.id },
      });
      customerId = customer.id;
      await prisma.user.update({
        where: { id: user.id },
        data: { stripeCustomerId: customerId },
      });
    }

    // إنشاء جلسة الدفع للاشتراك الشهري
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: process.env.STRIPE_PRO_PRICE_ID, // لازم تنشئه في لوحة تحكم Stripe
          quantity: 1,
        },
      ],
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?success=true`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/pricing?canceled=true`,
    });

    return NextResponse.json({ url: session.url });
  } catch (error: any) {
    if (error.name === 'UnauthorizedError') return unauthorizedResponse();
    console.error('[Stripe Checkout]', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}