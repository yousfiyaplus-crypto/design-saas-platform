import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { decrypt } from '@/lib/crypto';
import { buildFileTree, createVercelDeployment, VercelApiError } from '@/lib/vercel';
import { DeployRequestSchema } from '@/lib/validators/deploy.schema';
import { getUserIdOrThrow, UnauthorizedError } from '@/lib/auth/getUserId';

export const runtime = 'nodejs';
export const maxDuration = 45;

interface ApiErrorBody {
  error: string;
  message: string;
  code: string;
}

function errorResponse(body: ApiErrorBody, status: number) {
  return NextResponse.json(body, { status });
}

function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 52);
}

export async function POST(req: NextRequest) {
  let userId: string;
  try {
    userId = getUserIdOrThrow();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return errorResponse(
        { error: 'Unauthorized', message: 'A valid session is required.', code: 'UNAUTHORIZED' },
        401
      );
    }
    throw err;
  }

  let body: z.infer<typeof DeployRequestSchema>;
  try {
    body = DeployRequestSchema.parse(await req.json());
  } catch (err) {
    if (err instanceof z.ZodError) {
      return errorResponse(
        {
          error: 'ValidationError',
          message: err.errors.map((e) => `${e.path.join('.')}: ${e.message}`).join('; '),
          code: 'VALIDATION_ERROR',
        },
        400
      );
    }
    return errorResponse(
      { error: 'ValidationError', message: 'Invalid request body.', code: 'VALIDATION_ERROR' },
      400
    );
  }

  const { projectId, componentId, target } = body;
  let { code, projectName } = body;

  const project = await prisma.project.findFirst({
    where: { id: projectId, ownerId: userId },
    select: { id: true, name: true, vercelProjectId: true },
  });

  if (!project) {
    return errorResponse(
      { error: 'NotFound', message: 'Project not found or access denied.', code: 'PROJECT_NOT_FOUND' },
      404
    );
  }

  if (componentId) {
    const component = await prisma.component.findFirst({
      where: { id: componentId, projectId: project.id },
      select: { id: true, code: true, name: true },
    });

    if (!component) {
      return errorResponse(
        { error: 'NotFound', message: 'Component not found in this project.', code: 'COMPONENT_NOT_FOUND' },
        404
      );
    }

    code = component.code;
    if (!projectName) projectName = slugify(component.name);
  }

  if (!code) {
    return errorResponse(
      { error: 'ValidationError', message: 'No code available to deploy.', code: 'VALIDATION_ERROR' },
      400
    );
  }

  if (!projectName) {
    // IMPORTANT: for redeploys, the name must stay stable across calls so
    // that (combined with `project` id below) Vercel treats this as the
    // same project. Derive it from the Project record itself, not a
    // timestamp, once a vercelProjectId already exists.
    projectName = project.vercelProjectId
      ? slugify(project.name)
      : slugify(`${project.name}-${Date.now()}`);
  }

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { vercelToken: true, vercelTeamId: true, plan: true },
  });

  if (!user?.vercelToken) {
    return errorResponse(
      {
        error: 'VercelNotConnected',
        message: 'Connect your Vercel account before deploying.',
        code: 'VERCEL_NOT_CONNECTED',
      },
      400
    );
  }

  let accessToken: string;
  try {
    accessToken = decrypt(user.vercelToken);
  } catch (err) {
    console.error('[deploy] failed to decrypt Vercel token for user', userId, err);
    return errorResponse(
      {
        error: 'VercelTokenCorrupted',
        message: 'Your stored Vercel credentials could not be read. Please reconnect your Vercel account.',
        code: 'VERCEL_TOKEN_CORRUPTED',
      },
      400
    );
  }

  const files = buildFileTree(code, projectName);
  const isRedeploy = Boolean(project.vercelProjectId);

  const deploymentRecord = await prisma.deployment.create({
    data: {
      projectId: project.id,
      componentId: componentId ?? null,
      provider: 'VERCEL',
      status: 'QUEUED',
    },
  });

  try {
    let vercelDeployment;

    try {
      vercelDeployment = await createVercelDeployment({
        accessToken,
        teamId: user.vercelTeamId,
        projectName,
        existingVercelProjectId: project.vercelProjectId,
        files,
        target,
      });
    } catch (err) {
      // Stale link recovery: the linked Vercel project was deleted outside
      // our system. Clear the stale id and retry once as a fresh deploy
      // rather than permanently failing every future deploy for this project.
      if (err instanceof VercelApiError && err.vercelCode === 'PROJECT_NOT_FOUND') {
        console.warn(
          `[deploy] stale vercelProjectId for project ${project.id}, clearing and retrying fresh`
        );
        await prisma.project.update({
          where: { id: project.id },
          data: { vercelProjectId: null },
        });

        vercelDeployment = await createVercelDeployment({
          accessToken,
          teamId: user.vercelTeamId,
          projectName: slugify(`${project.name}-${Date.now()}`),
          existingVercelProjectId: null,
          files,
          target,
        });
      } else {
        throw err;
      }
    }

    const deploymentUrl = `https://${vercelDeployment.url}`;

    await prisma.$transaction([
      prisma.deployment.update({
        where: { id: deploymentRecord.id },
        data: {
          externalId: vercelDeployment.id,
          url: deploymentUrl,
          status: mapReadyState(vercelDeployment.readyState),
        },
      }),
      prisma.project.update({
        where: { id: project.id },
        data: { vercelProjectId: vercelDeployment.projectId },
      }),
    ]);

    return NextResponse.json({
      deploymentId: deploymentRecord.id,
      deploymentUrl,
      vercelDeploymentId: vercelDeployment.id,
      vercelProjectId: vercelDeployment.projectId,
      status: vercelDeployment.readyState,
      isRedeploy,
    });
  } catch (err) {
    const message =
      err instanceof VercelApiError ? err.message : 'Deployment failed due to an unexpected error.';
    const vercelCode = err instanceof VercelApiError ? err.vercelCode ?? 'UNKNOWN' : 'INTERNAL_ERROR';
    const status = err instanceof VercelApiError ? err.status : 500;

    console.error(
      JSON.stringify({
        event: 'DEPLOYMENT_FAILED',
        userId,
        projectId,
        deploymentRecordId: deploymentRecord.id,
        status,
        code: vercelCode,
        message,
        timestamp: new Date().toISOString(),
      })
    );

    await prisma.deployment.update({
      where: { id: deploymentRecord.id },
      data: { status: 'ERROR', logs: message },
    });

    const clientStatus = status === 401 || status === 403 ? status : 502;

    return errorResponse(
      { error: 'DeploymentFailed', message, code: `VERCEL_${vercelCode}` },
      clientStatus
    );
  }
}

function mapReadyState(
  state: 'QUEUED' | 'BUILDING' | 'READY' | 'ERROR' | 'CANCELED'
): 'QUEUED' | 'BUILDING' | 'READY' | 'ERROR' {
  if (state === 'CANCELED') return 'ERROR';
  return state;
}
