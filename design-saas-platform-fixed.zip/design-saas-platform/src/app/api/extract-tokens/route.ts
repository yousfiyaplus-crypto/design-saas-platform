import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { extractDesignTokens, SsrfBlockedError } from '@/lib/extractor';
import { ExtractTokensRequestSchema } from '@/lib/validators/extract.schema';
import { getUserIdOrThrow, UnauthorizedError } from '@/lib/auth/getUserId';

export const runtime = 'nodejs';
export const maxDuration = 15;

export async function POST(req: NextRequest) {
  let userId: string;
  try {
    userId = getUserIdOrThrow();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json(
        { error: 'Unauthorized', message: 'A valid session is required.' },
        { status: 401 }
      );
    }
    throw err;
  }

  let body: z.infer<typeof ExtractTokensRequestSchema>;
  try {
    body = ExtractTokensRequestSchema.parse(await req.json());
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: 'ValidationError',
          message: err.errors.map((e) => `${e.path.join('.')}: ${e.message}`).join('; '),
        },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'ValidationError', message: 'Invalid request body.' },
      { status: 400 }
    );
  }

  const project = await prisma.project.findFirst({
    where: { id: body.projectId, ownerId: userId },
    select: { id: true },
  });

  if (!project) {
    return NextResponse.json(
      { error: 'NotFound', message: 'Project not found or access denied.' },
      { status: 404 }
    );
  }

  try {
    const tokens = await extractDesignTokens(body.url);

    const saved = await prisma.designToken.upsert({
      where: { projectId: body.projectId },
      create: {
        projectId: body.projectId,
        colors: tokens.colors,
        fonts: tokens.fonts,
        radii: { default: tokens.radius },
        raw: tokens as unknown as object,
      },
      update: {
        colors: tokens.colors,
        fonts: tokens.fonts,
        radii: { default: tokens.radius },
        raw: tokens as unknown as object,
        extractedAt: new Date(),
      },
    });

    return NextResponse.json({ tokens, savedTokenId: saved.id });
  } catch (err) {
    if (err instanceof SsrfBlockedError) {
      return NextResponse.json(
        { error: 'SsrfBlocked', message: 'The provided URL could not be accessed for security reasons.' },
        { status: 400 }
      );
    }

    console.error('[extract-tokens] unexpected error:', err);
    return NextResponse.json(
      { error: 'InternalError', message: 'Could not extract design tokens.' },
      { status: 500 }
    );
  }
}
