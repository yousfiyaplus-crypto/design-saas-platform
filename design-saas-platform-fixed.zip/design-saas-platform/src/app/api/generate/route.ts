import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import crypto from 'crypto';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { safeGet, safeSetEx } from '@/lib/redis';
import {
  GenerateRequestSchema,
  GeneratedComponentSchema,
  type GeneratedComponent,
} from '@/lib/validators/generate.schema';
import { getUserIdOrThrow, UnauthorizedError } from '@/lib/auth/getUserId';

export const runtime = 'nodejs';
export const maxDuration = 60; // seconds, generous for GPT-4o on complex components

const CACHE_TTL_SECONDS = 60 * 60 * 24; // 24 hours
const OPENAI_TIMEOUT_MS = 45000;

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  timeout: OPENAI_TIMEOUT_MS,
  maxRetries: 2,
});

const FREE_TIER_MONTHLY_LIMIT = 3;

function buildSystemPrompt(framework: 'react' | 'vue'): string {
  return `You are a senior frontend engineer generating production-ready UI components.

STRICT OUTPUT RULES:
- Respond with ONLY a JSON object matching this exact shape: {"code": string, "explanation": string}.
- The "code" field must contain ONLY the raw component source code. No markdown code fences, no backticks, no triple-quotes, no language tags.
- The "code" field must be a complete, syntactically valid, runnable ${
    framework === 'react' ? 'React (TypeScript + Tailwind CSS, using shadcn/ui primitives where sensible)' : 'Vue 3 (Composition API + Tailwind CSS)'
  } component.
- Do not include any import of assets you cannot guarantee exist (e.g. no placeholder image URLs that 404 — use solid color divs or inline SVG instead).
- The "explanation" field is a concise (2-4 sentence) plain-text summary of what the component does and how it uses any provided design tokens. No markdown in this field either.
- Never include commentary, apologies, or meta-text outside the JSON object.
- If design tokens are provided, apply them (colors, fonts, border radii) via Tailwind arbitrary values or inline style where Tailwind config extension isn't possible in a single-file snippet.`;
}

function buildUserPrompt(
  prompt: string,
  designTokens: GenerateRequest['designTokens']
): string {
  let fullPrompt = `Component request: ${prompt}`;

  if (designTokens && Object.keys(designTokens).length > 0) {
    fullPrompt += `\n\nDesign tokens to apply (match these exactly where applicable):\n${JSON.stringify(
      designTokens,
      null,
      2
    )}`;
  }

  return fullPrompt;
}

/**
 * Deterministic cache key: sha256 of normalized prompt + framework + tokens.
 * Normalization (trim, lowercase prompt) avoids trivial cache misses from
 * whitespace/casing differences on otherwise-identical requests.
 */
function computePromptHash(
  prompt: string,
  framework: string,
  designTokens: unknown
): string {
  const normalizedPrompt = prompt.trim().toLowerCase();
  const normalizedTokens = designTokens
    ? JSON.stringify(designTokens, Object.keys(designTokens as object).sort())
    : '';

  const payload = `${normalizedPrompt}::${framework}::${normalizedTokens}`;
  return crypto.createHash('sha256').update(payload, 'utf8').digest('hex');
}

function cacheKeyFor(promptHash: string): string {
  return `component:${promptHash}`;
}

type GenerateRequest = z.infer<typeof GenerateRequestSchema>;

interface ApiErrorBody {
  error: string;
  message: string;
  code:
    | 'UNAUTHORIZED'
    | 'VALIDATION_ERROR'
    | 'RATE_LIMIT_EXCEEDED'
    | 'PROJECT_NOT_FOUND'
    | 'GENERATION_FAILED'
    | 'INTERNAL_ERROR';
}

function errorResponse(body: ApiErrorBody, status: number) {
  return NextResponse.json(body, { status });
}

export async function POST(req: NextRequest) {
  // ── 1. Auth ──────────────────────────────────────────────────────────
  let userId: string;
  try {
    userId = getUserIdOrThrow();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return errorResponse(
        {
          error: 'Unauthorized',
          message: 'A valid session is required.',
          code: 'UNAUTHORIZED',
        },
        401
      );
    }
    throw err;
  }

  // ── 2. Parse + validate input ───────────────────────────────────────
  let body: GenerateRequest;
  try {
    const json = await req.json();
    body = GenerateRequestSchema.parse(json);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return errorResponse(
        {
          error: 'ValidationError',
          message: err.errors.map((e) => `${e.path.join('.')}: ${e.message}`).join('; '),
          code: 'VALIDATION_ERROR',
        },
        400
      );
    }
    return errorResponse(
      {
        error: 'ValidationError',
        message: 'Request body must be valid JSON.',
        code: 'VALIDATION_ERROR',
      },
      400
    );
  }

  const { prompt, framework, designTokens, projectId } = body;

  // ── 3. Ownership check: project must belong to this user ───────────
  const project = await prisma.project.findFirst({
    where: { id: projectId, ownerId: userId },
    select: { id: true },
  });

  if (!project) {
    return errorResponse(
      {
        error: 'NotFound',
        message: 'Project not found or you do not have access to it.',
        code: 'PROJECT_NOT_FOUND',
      },
      404
    );
  }

  // ── 4. Enforce free-tier rate limit ─────────────────────────────────
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { plan: true, generationsThisMonth: true, usageResetAt: true },
  });

  if (!user) {
    return errorResponse(
      {
        error: 'Unauthorized',
        message: 'User record not found.',
        code: 'UNAUTHORIZED',
      },
      401
    );
  }

  const now = new Date();
  const resetDue =
    now.getUTCFullYear() !== user.usageResetAt.getUTCFullYear() ||
    now.getUTCMonth() !== user.usageResetAt.getUTCMonth();

  let currentUsage = user.generationsThisMonth;

  if (resetDue) {
    // Roll the monthly counter forward lazily on first request of the month.
    await prisma.user.update({
      where: { id: userId },
      data: { generationsThisMonth: 0, usageResetAt: now },
    });
    currentUsage = 0;
  }

  if (user.plan === 'FREE' && currentUsage >= FREE_TIER_MONTHLY_LIMIT) {
    return errorResponse(
      {
        error: 'RateLimitExceeded',
        message: `Free tier is limited to ${FREE_TIER_MONTHLY_LIMIT} generations per month. Upgrade to Pro for unlimited generations.`,
        code: 'RATE_LIMIT_EXCEEDED',
      },
      429
    );
  }

  // ── 5. Compute cache key ────────────────────────────────────────────
  const promptHash = computePromptHash(prompt, framework, designTokens);
  const cacheKey = cacheKeyFor(promptHash);

  // ── 6. Check Redis cache ────────────────────────────────────────────
  const cachedRaw = await safeGet(cacheKey);

  if (cachedRaw) {
    try {
      const cached = GeneratedComponentSchema.parse(JSON.parse(cachedRaw));
      console.log(
        JSON.stringify({
          event: 'CACHE_HIT',
          userId,
          projectId,
          promptHash,
          timestamp: new Date().toISOString(),
        })
      );

      // Still persist a Component row + increment usage so history/billing
      // stay accurate even on cache hits (user spent a "generation").
      const component = await persistComponent({
        projectId,
        name: deriveComponentName(prompt),
        prompt,
        framework,
        code: cached.code,
        promptHash,
        tokenUsage: 0,
      });

      await incrementUsage(userId);

      return NextResponse.json({
        id: component.id,
        code: cached.code,
        explanation: cached.explanation,
        cached: true,
        createdAt: component.createdAt,
      });
    } catch (err) {
      // Cached payload is corrupted/stale schema — fall through to regenerate.
      console.warn('[generate] cache hit but payload failed validation, regenerating', err);
    }
  }

  // ── 7. Cache miss: call OpenAI ──────────────────────────────────────
  console.log(
    JSON.stringify({
      event: 'CACHE_MISS',
      userId,
      projectId,
      promptHash,
      timestamp: new Date().toISOString(),
    })
  );

  let generated: GeneratedComponent;
  let tokenUsage = 0;

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      response_format: { type: 'json_object' },
      temperature: 0.4,
      messages: [
        { role: 'system', content: buildSystemPrompt(framework) },
        { role: 'user', content: buildUserPrompt(prompt, designTokens) },
      ],
    });

    const rawContent = completion.choices[0]?.message?.content;
    tokenUsage = completion.usage?.total_tokens ?? 0;

    if (!rawContent) {
      throw new Error('OpenAI returned an empty response.');
    }

    const parsedJson = JSON.parse(rawContent);
    generated = GeneratedComponentSchema.parse(parsedJson);

    // Defensive strip in case the model ignored instructions and wrapped
    // code in markdown fences despite json_object mode.
    generated.code = stripMarkdownFences(generated.code);
  } catch (err) {
    console.error(
      JSON.stringify({
        event: 'GENERATION_FAILED',
        userId,
        projectId,
        promptHash,
        error: err instanceof Error ? err.message : 'unknown',
        timestamp: new Date().toISOString(),
      })
    );

    // Never leak raw OpenAI/SDK error details to the client.
    return errorResponse(
      {
        error: 'GenerationFailed',
        message:
          'Component generation failed. Please try again; if the problem persists, contact support.',
        code: 'GENERATION_FAILED',
      },
      502
    );
  }

  // ── 8. Persist to Postgres (source of truth, cache is best-effort) ──
  let component;
  try {
    component = await persistComponent({
      projectId,
      name: deriveComponentName(prompt),
      prompt,
      framework,
      code: generated.code,
      promptHash,
      tokenUsage,
    });
  } catch (err) {
    console.error('[generate] failed to persist component to Postgres:', err);
    return errorResponse(
      {
        error: 'InternalError',
        message: 'Component was generated but could not be saved. Please retry.',
        code: 'INTERNAL_ERROR',
      },
      500
    );
  }

  // ── 9. Best-effort cache write (never block/fail the response on this) ─
  await safeSetEx(cacheKey, CACHE_TTL_SECONDS, JSON.stringify(generated));

  // ── 10. Increment usage counter ──────────────────────────────────────
  await incrementUsage(userId);

  return NextResponse.json({
    id: component.id,
    code: generated.code,
    explanation: generated.explanation,
    cached: false,
    createdAt: component.createdAt,
  });
}

// ── Helpers ─────────────────────────────────────────────────────────────

async function persistComponent(params: {
  projectId: string;
  name: string;
  prompt: string;
  framework: 'react' | 'vue';
  code: string;
  promptHash: string;
  tokenUsage: number;
}) {
  return prisma.component.create({
    data: {
      projectId: params.projectId,
      name: params.name,
      prompt: params.prompt,
      framework: params.framework.toUpperCase() as 'REACT' | 'VUE',
      code: params.code,
      promptHash: params.promptHash,
      tokenUsage: params.tokenUsage,
      status: 'SUCCESS',
    },
  });
}

async function incrementUsage(userId: string) {
  try {
    await prisma.user.update({
      where: { id: userId },
      data: { generationsThisMonth: { increment: 1 } },
    });
  } catch (err) {
    // Usage tracking failure shouldn't fail the whole request — log for
    // reconciliation but let the user keep their generated component.
    console.error('[generate] failed to increment usage counter:', err);
  }
}

function deriveComponentName(prompt: string): string {
  const words = prompt.trim().split(/\s+/).slice(0, 5).join(' ');
  return words.length > 0 ? words : 'Untitled Component';
}

/**
 * Defensive cleanup: strips ``` / ```tsx / ```jsx fences if the model
 * ignored the "no markdown" instruction despite json_object mode.
 */
function stripMarkdownFences(code: string): string {
  return code
    .replace(/^```[a-zA-Z]*\n?/, '')
    .replace(/```$/, '')
    .trim();
}
