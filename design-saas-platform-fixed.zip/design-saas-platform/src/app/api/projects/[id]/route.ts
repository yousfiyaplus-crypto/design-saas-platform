// src/app/api/projects/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getUserIdOrThrow, UnauthorizedError } from '@/lib/auth/getUserId';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  let userId: string;
  try {
    userId = getUserIdOrThrow();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    throw err;
  }

  const project = await prisma.project.findFirst({
    where: { id: params.id, ownerId: userId },
    include: {
      components: { orderBy: { createdAt: 'desc' } },
      designTokens: true,
      deployments: { orderBy: { createdAt: 'desc' }, take: 1 },
    },
  });

  if (!project) {
    return NextResponse.json({ error: 'NotFound' }, { status: 404 });
  }

  return NextResponse.json({ project });
}
