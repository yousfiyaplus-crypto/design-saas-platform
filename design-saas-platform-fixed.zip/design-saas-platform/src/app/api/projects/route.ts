// src/app/api/projects/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { getUserIdOrThrow, UnauthorizedError } from '@/lib/auth/getUserId';

export const runtime = 'nodejs';

const CreateProjectSchema = z.object({
  name: z.string().min(2).max(100),
  sourceUrl: z.string().url().optional(),
});

export async function GET() {
  let userId: string;
  try {
    userId = getUserIdOrThrow();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    throw err;
  }

  const projects = await prisma.project.findMany({
    where: { ownerId: userId },
    orderBy: { updatedAt: 'desc' },
    include: {
      components: { select: { id: true } },
      deployments: { orderBy: { createdAt: 'desc' }, take: 1, select: { url: true } },
    },
  });

  return NextResponse.json({
    projects: projects.map((p) => ({
      id: p.id,
      name: p.name,
      sourceUrl: p.sourceUrl,
      vercelProjectId: p.vercelProjectId,
      componentCount: p.components.length,
      lastDeploymentUrl: p.deployments[0]?.url ?? null,
      updatedAt: p.updatedAt,
    })),
  });
}

export async function POST(req: NextRequest) {
  let userId: string;
  try {
    userId = getUserIdOrThrow();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    throw err;
  }

  let body: z.infer<typeof CreateProjectSchema>;
  try {
    body = CreateProjectSchema.parse(await req.json());
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'ValidationError', message: err.errors.map((e) => e.message).join('; ') },
        { status: 400 }
      );
    }
    return NextResponse.json({ error: 'ValidationError' }, { status: 400 });
  }

  const project = await prisma.project.create({
    data: { name: body.name, sourceUrl: body.sourceUrl, ownerId: userId },
  });

  return NextResponse.json({ project });
}
