import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '@/lib/prisma';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// التحقق من أن الطلب قادم فعلاً من فيجما (حماية من التزوير)
function verifyFigmaSignature(payload: string, signature: string, secret: string): boolean {
  if (!signature || !secret) return false;

  const hmac = crypto.createHmac('sha256', secret);
  hmac.update(payload);
  const expected = Buffer.from(hmac.digest('hex'));
  const received = Buffer.from(signature);

  // timingSafeEqual throws on length mismatch instead of returning false —
  // guard explicitly so a malformed/forged header returns 401, not a 500.
  if (expected.length !== received.length) return false;

  return crypto.timingSafeEqual(expected, received);
}

export async function POST(req: NextRequest) {
  try {
    const rawBody = await req.text();
    const signature = req.headers.get('x-figma-signature') || '';
    const webhookSecret = process.env.FIGMA_WEBHOOK_SECRET || '';

    // 1. التحقق من التوقيع
    if (!verifyFigmaSignature(rawBody, signature, webhookSecret)) {
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
    }

    const payload = JSON.parse(rawBody);
    const { event_type, file_key } = payload;

    // 2. التحقق من نوع الحدث (نبي التعديلات على الملفات)
    if (event_type !== 'FILE_UPDATE' && event_type !== 'FILE_VERSION_UPDATE') {
      return NextResponse.json({ message: 'Event ignored' }, { status: 200 });
    }

    // 3. البحث عن المشروع المرتبط بملف فيجما هذا
    const figmaConnection = await prisma.figmaConnection.findFirst({
      where: { fileKey: file_key },
      include: { user: true },
    });

    if (!figmaConnection) {
      return NextResponse.json({ message: 'No connection found for this file' }, { status: 200 });
    }

    // 4. الحصول على أحدث مكون (Component) في هذا المشروع عشان نحدثه
    const project = await prisma.project.findFirst({
      where: { figmaFileKey: file_key },
      include: { components: { orderBy: { createdAt: 'desc' }, take: 1 } },
    });

    if (!project || project.components.length === 0) {
      return NextResponse.json({ message: 'No components to update' }, { status: 200 });
    }

    const latestComponent = project.components[0];

    // 5. إعادة التوليد بالذكاء الاصطناعي (تحديث الكود بناءً على التصميم الجديد)
    // ملاحظة: في بيئة الإنتاج، يجب جلب صورة جديدة من فيجما هنا، لكننا نستخدم الـ Prompt السابق
    const systemPrompt = `You are an expert Frontend Engineer. Update the following React code to reflect the latest Figma design changes. Return ONLY the code.`;
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Original Code:\n${latestComponent.code}\n\nUpdate it based on the latest design.` }
      ],
      temperature: 0.2,
    });

    let newCode = response.choices[0].message.content || "";
    newCode = newCode.replace(/```tsx/g, "").replace(/```jsx/g, "").replace(/```/g, "").trim();

    // 6. حفظ النسخة الجديدة في قاعدة البيانات (إنشاء نسخة جديدة version)
    await prisma.component.create({
      data: {
        projectId: project.id,
        name: `${latestComponent.name} (Figma Sync)`,
        prompt: latestComponent.prompt,
        framework: 'REACT',
        code: newCode,
        promptHash: crypto.createHash('sha256').update(newCode).digest('hex'),
        status: 'SUCCESS',
      }
    });

    return NextResponse.json({ success: true, message: 'Component regenerated' });

  } catch (error: any) {
    console.error('[Figma Webhook Error]', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}