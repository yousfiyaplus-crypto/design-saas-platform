import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { z } from 'zod';
import OpenAI from 'openai';
import { prisma } from '@/lib/prisma';
import { getUserIdOrThrow, UnauthorizedError } from '@/lib/auth/getUserId';

export const runtime = 'nodejs';
export const maxDuration = 45;

/**
 * Manual Figma sync, triggered by the user from the dashboard ("Sync now"
 * button) rather than by Figma's webhook. Reuses the same regeneration
 * logic as /api/figma/webhook/route.ts, but is authenticated via the
 * normal user session (middleware) instead of a webhook signature, and
 * scoped to projects the requesting user actually owns.
 */

const SyncRequestSchema = z.object({
  projectId: z.string().uuid('projectId must be a valid UUID.'),
});

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  timeout: 45000,
  maxRetries: 2,
});

export async function POST(req: NextRequest) {
  let userId: string;
  try {
    userId = getUserIdOrThrow();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    throw err;
  }

  let body: z.infer<typeof SyncRequestSchema>;
  try {
    body = SyncRequestSchema.parse(await req.json());
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'ValidationError', message: err.errors.map((e) => e.message).join('; ') },
        { status: 400 }
      );
    }
    return NextResponse.json({ error: 'ValidationError' }, { status: 400 });
  }

  const project = await prisma.project.findFirst({
    where: { id: body.projectId, ownerId: userId },
    include: { components: { orderBy: { createdAt: 'desc' }, take: 1 } },
  });

  if (!project) {
    return NextResponse.json(
      { error: 'NotFound', message: 'Project not found or access denied.' },
      { status: 404 }
    );
  }

  if (!project.figmaFileKey) {
    return NextResponse.json(
      { error: 'NoFigmaLink', message: 'This project is not linked to a Figma file yet.' },
      { status: 400 }
    );
  }

  if (project.components.length === 0) {
    return NextResponse.json(
      { error: 'NoComponents', message: 'Generate a component before syncing from Figma.' },
      { status: 400 }
    );
  }

  const latestComponent = project.components[0];

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      temperature: 0.2,
      messages: [
        {
          role: 'system',
          content:
            'You are an expert frontend engineer. Update the following React + Tailwind component to reflect the latest Figma design changes. Return ONLY the raw component code, no markdown fences, no commentary.',
        },
        {
          role: 'user',
          content: `Original component code:\n${latestComponent.code}\n\nRegenerate it, keeping the same structure and props where reasonable, reflecting the latest design sync.`,
        },
      ],
    });

    let newCode = completion.choices[0]?.message?.content ?? '';
    newCode = newCode
      .replace(/^```[a-zA-Z]*\n?/, '')
      .replace(/```$/, '')
      .trim();

    if (!newCode) {
      throw new Error('OpenAI returned an empty response.');
    }

    const synced = await prisma.component.create({
      data: {
        projectId: project.id,
        name: `${latestComponent.name} (Figma Sync)`,
        prompt: latestComponent.prompt,
        framework: 'REACT',
        code: newCode,
        promptHash: crypto.createHash('sha256').update(newCode).digest('hex'),
        status: 'SUCCESS',
      },
    });

    return NextResponse.json({ component: synced });
  } catch (err) {
    console.error('[figma/sync] regeneration failed:', err);
    return NextResponse.json(
      { error: 'SyncFailed', message: 'Could not sync from Figma. Please try again.' },
      { status: 502 }
    );
  }
}
