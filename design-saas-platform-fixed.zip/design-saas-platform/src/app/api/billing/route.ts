import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getUserIdOrThrow, UnauthorizedError } from '@/lib/auth/getUserId';

export const runtime = 'nodejs';

export async function GET() {
  let userId: string;
  try {
    userId = getUserIdOrThrow();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    throw err;
  }

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      plan: true,
      generationsThisMonth: true,
      usageResetAt: true,
      subscription: {
        select: { status: true, currentPeriodEnd: true, cancelAtPeriodEnd: true },
      },
    },
  });

  if (!user) {
    return NextResponse.json({ error: 'NotFound' }, { status: 404 });
  }

  return NextResponse.json({ billing: user });
}
