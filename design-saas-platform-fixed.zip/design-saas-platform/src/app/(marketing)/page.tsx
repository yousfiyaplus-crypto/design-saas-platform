import Link from 'next/link';
import { ArrowRight, Figma, Rocket, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

export default function MarketingHomePage() {
  return (
    <div className="flex flex-col">
      <section className="mx-auto max-w-4xl px-6 py-24 text-center">
        <h1 className="text-4xl font-semibold tracking-tight sm:text-5xl">
          Generate on-brand UI components in seconds
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
          Pull your design tokens from your website or Figma file, generate React + Tailwind
          components that match your brand, and deploy them live with one click.
        </p>
        <div className="mt-8 flex items-center justify-center gap-3">
          <Button asChild size="lg">
            <Link href="/register">
              Get started free <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/pricing">View pricing</Link>
          </Button>
        </div>
      </section>

      <section className="mx-auto grid max-w-5xl grid-cols-1 gap-6 px-6 pb-24 sm:grid-cols-3">
        <Card>
          <CardHeader>
            <Sparkles className="mb-2 h-6 w-6" />
            <CardTitle className="text-base">AI generation</CardTitle>
            <CardDescription>
              Describe a component in plain English and get production-ready React + Tailwind
              code, matched to your brand&apos;s colors, fonts, and spacing.
            </CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <Figma className="mb-2 h-6 w-6" />
            <CardTitle className="text-base">Figma sync</CardTitle>
            <CardDescription>
              Connect a Figma file and keep your generated components up to date as your design
              evolves.
            </CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <Rocket className="mb-2 h-6 w-6" />
            <CardTitle className="text-base">One-click deploy</CardTitle>
            <CardDescription>
              Ship straight to your own Vercel account — no copy-pasting code into a separate
              repo.
            </CardDescription>
          </CardHeader>
        </Card>
      </section>
    </div>
  );
}
