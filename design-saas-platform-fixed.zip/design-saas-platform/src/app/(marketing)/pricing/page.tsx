'use client';

import { useState } from 'react';
import { Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';

const FREE_FEATURES = ['3 components / month', '1 project', 'Design token extraction'];
const PRO_FEATURES = [
  'Unlimited components',
  'Unlimited projects',
  'Figma sync',
  'One-click Vercel deploy',
  'Priority generation',
];

export default function PricingPage() {
  const { toast } = useToast();
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  async function handleUpgrade() {
    setIsCheckingOut(true);
    try {
      const res = await fetch('/api/stripe/checkout', { method: 'POST' });
      const data = await res.json();

      if (!res.ok || !data.url) {
        throw new Error(data?.error ?? 'Could not start checkout.');
      }

      window.location.href = data.url;
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Checkout failed',
        description: err instanceof Error ? err.message : 'Please sign in and try again.',
      });
      setIsCheckingOut(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-20">
      <div className="mb-12 text-center">
        <h1 className="text-3xl font-semibold tracking-tight">Simple, transparent pricing</h1>
        <p className="mt-2 text-muted-foreground">Start free. Upgrade when you need more.</p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Free</CardTitle>
            <CardDescription>For trying things out</CardDescription>
            <p className="pt-2 text-3xl font-semibold">$0</p>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              {FREE_FEATURES.map((f) => (
                <li key={f} className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-muted-foreground" /> {f}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="border-primary">
          <CardHeader>
            <CardTitle>Pro</CardTitle>
            <CardDescription>For shipping real products</CardDescription>
            <p className="pt-2 text-3xl font-semibold">
              $15 <span className="text-sm font-normal text-muted-foreground">/ month</span>
            </p>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              {PRO_FEATURES.map((f) => (
                <li key={f} className="flex items-center gap-2">
                  <Check className="h-4 w-4" /> {f}
                </li>
              ))}
            </ul>
          </CardContent>
          <CardFooter>
            <Button className="w-full" onClick={handleUpgrade} disabled={isCheckingOut}>
              {isCheckingOut ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Upgrade to Pro'}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
