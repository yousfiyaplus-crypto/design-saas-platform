import { createBrowserClient } from '@supabase/ssr';

/**
 * Browser-side Supabase client (for use in Client Components: login forms,
 * OAuth sign-in buttons, etc). Uses the public anon key — safe to expose,
 * RLS and the API-route JWT checks (middleware.ts) are what actually
 * enforce access control.
 */
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
