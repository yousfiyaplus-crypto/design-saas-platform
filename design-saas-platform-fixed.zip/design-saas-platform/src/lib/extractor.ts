import * as cheerio from 'cheerio';
import dns from 'dns';
import ipaddr from 'ipaddr.js';
import { promisify } from 'util';

const dnsLookup = promisify(dns.lookup);

// ─────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────

export interface DesignTokens {
  colors: string[];
  fonts: string[];
  radius: string;
}

export class SsrfBlockedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SsrfBlockedError';
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Config
// ─────────────────────────────────────────────────────────────────────────

const FETCH_TIMEOUT_MS = 5000;
const MAX_REDIRECTS = 3;
const MAX_RESPONSE_BYTES = 5 * 1024 * 1024; // 5MB cap on HTML payload
const ALLOWED_PROTOCOLS = new Set(['http:', 'https:']);

const DEFAULT_TOKENS: DesignTokens = {
  colors: ['#3B82F6', '#1E293B', '#F8FAFC'],
  fonts: ['Inter', 'system-ui', 'sans-serif'],
  radius: '0.375rem',
};

// Explicit blocklist of hostnames commonly used to reach metadata/internal
// services, even when they don't immediately resolve to an obviously
// private IP (defense in depth alongside the IP-range check below).
const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  'metadata.google.internal',
  '169.254.169.254', // AWS/GCP/Azure instance metadata
]);

// ─────────────────────────────────────────────────────────────────────────
// SSRF Guard
// ─────────────────────────────────────────────────────────────────────────

/**
 * Validates a URL string and protocol before any network activity.
 * Throws SsrfBlockedError on anything suspicious.
 */
function validateUrlShape(rawUrl: string): URL {
  let parsed: URL;

  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new SsrfBlockedError('Invalid URL format.');
  }

  if (!ALLOWED_PROTOCOLS.has(parsed.protocol)) {
    throw new SsrfBlockedError(
      `Protocol "${parsed.protocol}" is not allowed. Only http/https are permitted.`
    );
  }

  const hostname = parsed.hostname.toLowerCase();

  if (BLOCKED_HOSTNAMES.has(hostname)) {
    throw new SsrfBlockedError(`Hostname "${hostname}" is explicitly blocked.`);
  }

  // Reject credentials embedded in the URL (http://user:pass@host) — not
  // an SSRF vector per se, but not something we want to be forwarding.
  if (parsed.username || parsed.password) {
    throw new SsrfBlockedError('URLs with embedded credentials are not allowed.');
  }

  // Reject non-standard ports commonly used for internal services
  // (databases, admin panels, etc). Allow default 80/443 and explicit
  // 80/443/8080/8443 for sites that front with a proxy on those.
  const allowedPorts = new Set(['', '80', '443', '8080', '8443']);
  if (!allowedPorts.has(parsed.port)) {
    throw new SsrfBlockedError(`Port "${parsed.port}" is not allowed.`);
  }

  return parsed;
}

/**
 * Resolves a hostname to its IP address(es) and verifies none of them
 * fall in a private, loopback, link-local, or otherwise reserved range.
 * This is the critical SSRF check: DNS can return a private IP for a
 * public-looking domain name ("DNS rebinding" style attacks), so we must
 * resolve and check the actual IP, not just trust the hostname string.
 */
async function assertPublicIp(hostname: string): Promise<string> {
  // If the "hostname" is already a literal IP, skip DNS and check directly.
  if (ipaddr.isValid(hostname)) {
    assertIpIsPublic(hostname);
    return hostname;
  }

  let address: string;

  try {
    const result = await dnsLookup(hostname, { all: false });
    address = result.address;
  } catch (err) {
    throw new SsrfBlockedError(`Could not resolve hostname "${hostname}".`);
  }

  assertIpIsPublic(address);
  return address;
}

function assertIpIsPublic(ip: string): void {
  let addr: ipaddr.IPv4 | ipaddr.IPv6;

  try {
    addr = ipaddr.process(ip); // normalizes IPv4-mapped IPv6 to IPv4 where applicable
  } catch {
    throw new SsrfBlockedError(`Invalid resolved IP address: "${ip}".`);
  }

  const range = addr.range();

  // ipaddr.js range() returns one of:
  // 'unicast', 'unspecified', 'broadcast', 'multicast', 'linkLocal',
  // 'loopback', 'private', 'reserved', 'carrierGradeNat', etc.
  const BLOCKED_RANGES = new Set([
    'unspecified',
    'broadcast',
    'multicast',
    'linkLocal',
    'loopback',
    'private',
    'reserved',
    'carrierGradeNat',
    'uniqueLocal', // IPv6 equivalent of private
  ]);

  if (BLOCKED_RANGES.has(range)) {
    throw new SsrfBlockedError(
      `Resolved IP "${ip}" falls in a blocked range ("${range}").`
    );
  }
}

/**
 * Fetches a URL with:
 *  - Manual redirect handling (each redirect hop is re-validated against
 *    the same SSRF checks — critical, since an attacker-controlled site
 *    could 302 to http://169.254.169.254/ and a naive `redirect: 'follow'`
 *    would happily follow it).
 *  - A hard timeout via AbortController.
 *  - A response size cap to avoid memory exhaustion on huge pages.
 */
async function safeFetchHtml(initialUrl: string): Promise<string> {
  let currentUrl = initialUrl;

  for (let redirectCount = 0; redirectCount <= MAX_REDIRECTS; redirectCount++) {
    const parsed = validateUrlShape(currentUrl);
    const resolvedIp = await assertPublicIp(parsed.hostname);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

    let response: Response;

    try {
      response = await fetch(parsed.toString(), {
        method: 'GET',
        redirect: 'manual', // we handle redirects ourselves to re-validate each hop
        signal: controller.signal,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (compatible; DesignTokenBot/1.0; +https://yourapp.com/bot)',
          Accept: 'text/html,application/xhtml+xml',
        },
      });
    } catch (err) {
      clearTimeout(timeoutId);
      if (err instanceof Error && err.name === 'AbortError') {
        throw new Error(`Request to "${currentUrl}" timed out after ${FETCH_TIMEOUT_MS}ms.`);
      }
      throw new Error(`Network error fetching "${currentUrl}": ${(err as Error).message}`);
    } finally {
      clearTimeout(timeoutId);
    }

    // Manual redirect handling
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get('location');
      if (!location) {
        throw new Error(`Redirect response from "${currentUrl}" missing Location header.`);
      }
      // Resolve relative redirects against the current URL
      currentUrl = new URL(location, currentUrl).toString();
      continue;
    }

    if (!response.ok) {
      throw new Error(`Site responded with status ${response.status} (${resolvedIp}).`);
    }

    const contentLengthHeader = response.headers.get('content-length');
    if (contentLengthHeader && Number(contentLengthHeader) > MAX_RESPONSE_BYTES) {
      throw new Error('Response exceeds maximum allowed size.');
    }

    // Stream-read with a hard cap even if Content-Length is absent/lying.
    const reader = response.body?.getReader();
    if (!reader) {
      return await response.text();
    }

    const chunks: Uint8Array[] = [];
    let totalBytes = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        totalBytes += value.byteLength;
        if (totalBytes > MAX_RESPONSE_BYTES) {
          reader.cancel();
          throw new Error('Response exceeded maximum allowed size while streaming.');
        }
        chunks.push(value);
      }
    }

    const buffer = Buffer.concat(chunks.map((c) => Buffer.from(c)));
    return buffer.toString('utf-8');
  }

  throw new Error(`Too many redirects (max ${MAX_REDIRECTS}) while fetching "${initialUrl}".`);
}

// ─────────────────────────────────────────────────────────────────────────
// Token Extraction (Cheerio)
// ─────────────────────────────────────────────────────────────────────────

const HEX_COLOR_REGEX = /#(?:[0-9a-fA-F]{3}){1,2}\b/g;
const RGB_COLOR_REGEX = /rgba?\([^)]+\)/g;
const HSL_COLOR_REGEX = /hsla?\([^)]+\)/g;
const CSS_VAR_COLOR_REGEX =
  /--[\w-]*(?:color|primary|secondary|accent|brand)[\w-]*\s*:\s*([^;]+);/gi;
const FONT_FAMILY_REGEX = /font-family\s*:\s*([^;}"]+)/gi;
const BORDER_RADIUS_REGEX = /border-radius\s*:\s*([^;}"]+)/gi;

// Colors to discard as noise (common resets / not brand-meaningful)
const IGNORED_COLORS = new Set([
  '#fff',
  '#ffffff',
  '#000',
  '#000000',
  'transparent',
  'inherit',
  'currentcolor',
]);

function extractColors($: cheerio.CheerioAPI, rawHtml: string): string[] {
  const found = new Set<string>();

  // 1. CSS custom properties that look brand-related
  for (const match of rawHtml.matchAll(CSS_VAR_COLOR_REGEX)) {
    const value = match[1]?.trim();
    if (value) found.add(value);
  }

  // 2. <style> tag contents
  $('style').each((_, el) => {
    const css = $(el).text();
    collectColorMatches(css, found);
  });

  // 3. Inline style attributes
  $('[style]').each((_, el) => {
    const styleAttr = $(el).attr('style') ?? '';
    collectColorMatches(styleAttr, found);
  });

  // 4. meta theme-color (PWA manifest hint — strong brand color signal)
  const themeColor = $('meta[name="theme-color"]').attr('content');
  if (themeColor) found.add(themeColor.trim());

  const filtered = Array.from(found)
    .map((c) => c.trim())
    .filter((c) => c.length > 0 && !IGNORED_COLORS.has(c.toLowerCase()));

  return filtered.slice(0, 8); // cap to a reasonable palette size
}

function collectColorMatches(css: string, found: Set<string>): void {
  for (const match of css.matchAll(HEX_COLOR_REGEX)) found.add(match[0]);
  for (const match of css.matchAll(RGB_COLOR_REGEX)) found.add(match[0]);
  for (const match of css.matchAll(HSL_COLOR_REGEX)) found.add(match[0]);
}

function extractFonts($: cheerio.CheerioAPI, rawHtml: string): string[] {
  const found = new Set<string>();

  $('style').each((_, el) => {
    const css = $(el).text();
    collectFontMatches(css, found);
  });

  $('[style]').each((_, el) => {
    const styleAttr = $(el).attr('style') ?? '';
    collectFontMatches(styleAttr, found);
  });

  // Google Fonts <link> tags are a strong, reliable signal
  $('link[href*="fonts.googleapis.com"]').each((_, el) => {
    const href = $(el).attr('href') ?? '';
    const familyParam = new URLSearchParams(href.split('?')[1] ?? '').get('family');
    if (familyParam) {
      familyParam.split('|').forEach((entry) => {
        const name = entry.split(':')[0]?.replace(/\+/g, ' ').trim();
        if (name) found.add(name);
      });
    }
  });

  const filtered = Array.from(found)
    .map((f) => f.replace(/['"]/g, '').trim())
    .filter((f) => f.length > 0);

  return filtered.slice(0, 5);
}

function collectFontMatches(css: string, found: Set<string>): void {
  for (const match of css.matchAll(FONT_FAMILY_REGEX)) {
    const value = match[1]?.trim();
    if (value) {
      // font-family can be a comma list; take the first (primary) font
      const primary = value.split(',')[0]?.replace(/['"]/g, '').trim();
      if (primary) found.add(primary);
    }
  }
}

function extractRadius($: cheerio.CheerioAPI, rawHtml: string): string {
  const values: string[] = [];

  $('style').each((_, el) => {
    const css = $(el).text();
    for (const match of css.matchAll(BORDER_RADIUS_REGEX)) {
      const value = match[1]?.trim();
      if (value && value !== '0' && value !== '0px') values.push(value);
    }
  });

  $('[style*="border-radius"]').each((_, el) => {
    const styleAttr = $(el).attr('style') ?? '';
    const match = styleAttr.match(/border-radius\s*:\s*([^;]+)/i);
    if (match?.[1]) values.push(match[1].trim());
  });

  // Tailwind utility class hints (rounded-md, rounded-lg, rounded-xl, rounded-full)
  const tailwindRadiusMap: Record<string, string> = {
    'rounded-sm': '0.125rem',
    rounded: '0.25rem',
    'rounded-md': '0.375rem',
    'rounded-lg': '0.5rem',
    'rounded-xl': '0.75rem',
    'rounded-2xl': '1rem',
    'rounded-full': '9999px',
  };

  for (const [className, radiusValue] of Object.entries(tailwindRadiusMap)) {
    if (rawHtml.includes(`"${className}`) || rawHtml.includes(` ${className}`)) {
      values.push(radiusValue);
    }
  }

  if (values.length === 0) {
    return DEFAULT_TOKENS.radius;
  }

  // Return the most frequently occurring value as the "representative" radius
  const frequency = new Map<string, number>();
  for (const v of values) {
    frequency.set(v, (frequency.get(v) ?? 0) + 1);
  }

  const [mostCommon] = Array.from(frequency.entries()).sort((a, b) => b[1] - a[1]);
  return mostCommon[0];
}

// ─────────────────────────────────────────────────────────────────────────
// Public API
// ─────────────────────────────────────────────────────────────────────────

/**
 * Extracts design tokens (colors, fonts, border radius) from a public URL.
 *
 * SSRF-safe: validates protocol, resolves DNS and checks the IP isn't
 * private/loopback/link-local, and re-validates every redirect hop.
 *
 * Never throws for network/scraping failures — always resolves to a
 * DesignTokens object, falling back to sane defaults so the generation
 * pipeline (Step 3) always has usable tokens to work with.
 */
export async function extractDesignTokens(targetUrl: string): Promise<DesignTokens> {
  try {
    // Validate shape + protocol before touching the network at all.
    validateUrlShape(targetUrl);

    const html = await safeFetchHtml(targetUrl);
    const $ = cheerio.load(html);

    const colors = extractColors($, html);
    const fonts = extractFonts($, html);
    const radius = extractRadius($, html);

    return {
      colors: colors.length > 0 ? colors : DEFAULT_TOKENS.colors,
      fonts: fonts.length > 0 ? fonts : DEFAULT_TOKENS.fonts,
      radius,
    };
  } catch (err) {
    if (err instanceof SsrfBlockedError) {
      // Re-throw SSRF violations — this is a security decision, not a
      // "site was unreachable" case, and the caller (API route) should
      // return a 400, not silently fall back and mask the attempt.
      throw err;
    }

    // Any other failure (timeout, 403/Cloudflare block, malformed HTML,
    // DNS failure for a real-but-unreachable domain, etc.) degrades to
    // defaults rather than failing the whole generation request.
    console.warn(
      `[extractor] falling back to default tokens for "${targetUrl}":`,
      err instanceof Error ? err.message : err
    );
    return { ...DEFAULT_TOKENS };
  }
}
