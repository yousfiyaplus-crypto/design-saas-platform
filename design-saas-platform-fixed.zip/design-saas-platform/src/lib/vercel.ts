// ── Add to the existing file from Step 5 ──────────────────────────────

export interface VercelDeploymentResponse {
  id: string;
  url: string;
  readyState: 'QUEUED' | 'BUILDING' | 'READY' | 'ERROR' | 'CANCELED';
  name: string;
  projectId: string; // NEW — Vercel's internal project id, persisted for redeploys
}

export async function createVercelDeployment(params: {
  accessToken: string;
  teamId?: string | null;
  projectName: string;
  existingVercelProjectId?: string | null; // NEW
  files: VercelFile[];
  target: 'production' | 'preview';
}): Promise<VercelDeploymentResponse> {
  const { accessToken, teamId, projectName, existingVercelProjectId, files, target } = params;

  const url = new URL(`${VERCEL_API_BASE}/v13/deployments`);
  if (teamId) {
    url.searchParams.set('teamId', teamId);
  }

  const payload: Record<string, unknown> = {
    name: projectName,
    files: files.map((f) => ({ file: f.file, data: f.data })),
    projectSettings: {
      framework: 'nextjs',
      buildCommand: null,
      outputDirectory: null,
      installCommand: null,
      devCommand: null,
    },
    target,
  };

  // Explicitly bind to the existing Vercel project rather than relying on
  // name-matching. This is what makes a "redeploy" update the same live
  // site (same URL on `target: "production"`) instead of spinning up a
  // brand-new project every time.
  if (existingVercelProjectId) {
    payload.project = existingVercelProjectId;
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), DEPLOY_TIMEOUT_MS);

  let response: Response;

  try {
    response = await fetch(url.toString(), {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timeoutId);
    if (err instanceof Error && err.name === 'AbortError') {
      throw new VercelApiError(504, 'TIMEOUT', 'Vercel deployment request timed out.');
    }
    throw new VercelApiError(
      502,
      'NETWORK_ERROR',
      `Network error contacting Vercel: ${(err as Error).message}`
    );
  } finally {
    clearTimeout(timeoutId);
  }

  const body = await response.json().catch(() => null);

  if (!response.ok) {
    const vercelCode: string | undefined = body?.error?.code;
    const vercelMessage: string = body?.error?.message ?? 'Unknown Vercel API error.';

    // Specific case: the stored vercelProjectId no longer exists on Vercel
    // (user deleted the project directly in their Vercel dashboard). We
    // surface a distinct code so the route handler can clear the stale id
    // and retry as a fresh deploy instead of failing permanently.
    if (response.status === 404 && existingVercelProjectId) {
      throw new VercelApiError(
        404,
        'PROJECT_NOT_FOUND',
        'The linked Vercel project no longer exists. It may have been deleted.'
      );
    }

    switch (response.status) {
      case 401:
        throw new VercelApiError(
          401,
          vercelCode,
          'Vercel access token is invalid or expired. Please reconnect your Vercel account.'
        );
      case 403:
        throw new VercelApiError(
          403,
          vercelCode,
          'Vercel access token does not have permission to deploy to this scope/team.'
        );
      case 400:
        throw new VercelApiError(
          400,
          vercelCode,
          `Vercel rejected the deployment payload: ${vercelMessage}`
        );
      case 429:
        throw new VercelApiError(
          429,
          vercelCode,
          'Vercel API rate limit exceeded. Please try again shortly.'
        );
      default:
        throw new VercelApiError(
          response.status,
          vercelCode,
          `Vercel API error (${response.status}): ${vercelMessage}`
        );
    }
  }

  if (!body?.id || !body?.url || !body?.projectId) {
    throw new VercelApiError(
      502,
      'MALFORMED_RESPONSE',
      'Vercel API returned an unexpected response shape.'
    );
  }

  return {
    id: body.id,
    url: body.url,
    readyState: body.readyState ?? 'QUEUED',
    name: body.name ?? projectName,
    projectId: body.projectId,
  };
}
