import Redis from 'ioredis';

/**
 * Singleton Redis client (ioredis) with auto-reconnect and structured
 * error handling. Mirrors the Prisma singleton pattern to survive
 * Next.js dev hot-reloads without leaking connections.
 */

declare global {
  // eslint-disable-next-line no-var
  var __redis: Redis | undefined;
}

const REDIS_URL = process.env.REDIS_URL;

if (!REDIS_URL) {
  throw new Error('REDIS_URL is not set in the environment.');
}

function createRedisClient(): Redis {
  const client = new Redis(REDIS_URL as string, {
    maxRetriesPerRequest: 2, // fail fast per-command so callers can fallback to Postgres
    retryStrategy(times: number) {
      // Exponential backoff capped at 5s, gives up logging noisily after a while
      const delay = Math.min(times * 200, 5000);
      return delay;
    },
    reconnectOnError(err: Error) {
      const targetErrors = ['READONLY', 'ECONNRESET', 'ETIMEDOUT'];
      return targetErrors.some((code) => err.message.includes(code));
    },
    lazyConnect: false,
    enableOfflineQueue: true,
    connectTimeout: 10000,
  });

  client.on('connect', () => {
    console.log('[redis] connecting...');
  });

  client.on('ready', () => {
    console.log('[redis] connection ready');
  });

  client.on('error', (err) => {
    // Never throw here — this listener exists specifically so ioredis
    // doesn't crash the process on connection errors. Callers must still
    // wrap individual commands in try/catch since a mid-request drop
    // will reject the in-flight promise.
    console.error('[redis] connection error:', err.message);
  });

  client.on('close', () => {
    console.warn('[redis] connection closed');
  });

  client.on('reconnecting', (delay: number) => {
    console.warn(`[redis] reconnecting in ${delay}ms`);
  });

  return client;
}

export const redis: Redis = global.__redis ?? createRedisClient();

if (process.env.NODE_ENV !== 'production') {
  global.__redis = redis;
}

/**
 * Safe wrapper: get a key, returning null on any Redis failure instead
 * of throwing. Use this everywhere caching is "nice to have, not required".
 */
export async function safeGet(key: string): Promise<string | null> {
  try {
    return await redis.get(key);
  } catch (err) {
    console.error(`[redis] safeGet failed for key "${key}":`, err);
    return null;
  }
}

/**
 * Safe wrapper: set a key with TTL (seconds), swallowing errors.
 * Returns true on success, false if Redis was unavailable.
 */
export async function safeSetEx(
  key: string,
  ttlSeconds: number,
  value: string
): Promise<boolean> {
  try {
    await redis.setex(key, ttlSeconds, value);
    return true;
  } catch (err) {
    console.error(`[redis] safeSetEx failed for key "${key}":`, err);
    return false;
  }
}

export default redis;
