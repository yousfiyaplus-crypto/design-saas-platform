import crypto from 'crypto';

/**
 * AES-256-GCM encryption utility for secrets at rest (Figma tokens, etc.)
 *
 * Storage format (base64, single string so it fits in one DB column):
 *   base64( iv (12 bytes) | authTag (16 bytes) | ciphertext )
 *
 * Key management:
 *   ENCRYPTION_KEY must be a 32-byte key, provided as a 64-char hex string
 *   in the environment. Generate one with:
 *     node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
 */

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12; // recommended IV length for GCM
const AUTH_TAG_LENGTH = 16;
const KEY_LENGTH = 32; // 256 bits

let cachedKey: Buffer | null = null;

function getEncryptionKey(): Buffer {
  if (cachedKey) return cachedKey;

  const rawKey = process.env.ENCRYPTION_KEY;

  if (!rawKey) {
    throw new Error(
      'ENCRYPTION_KEY is not set. Generate one with: ' +
        `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
    );
  }

  if (!/^[0-9a-fA-F]{64}$/.test(rawKey)) {
    throw new Error(
      'ENCRYPTION_KEY must be a 64-character hex string (32 bytes / 256 bits).'
    );
  }

  const key = Buffer.from(rawKey, 'hex');

  if (key.length !== KEY_LENGTH) {
    throw new Error(
      `ENCRYPTION_KEY decoded to ${key.length} bytes, expected ${KEY_LENGTH}.`
    );
  }

  cachedKey = key;
  return cachedKey;
}

/**
 * Encrypts a plaintext string (e.g. a Figma access token) for storage.
 * Returns a single base64 string containing iv + authTag + ciphertext.
 */
export function encrypt(plaintext: string): string {
  if (typeof plaintext !== 'string' || plaintext.length === 0) {
    throw new Error('encrypt() requires a non-empty string.');
  }

  const key = getEncryptionKey();
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);

  const ciphertext = Buffer.concat([
    cipher.update(plaintext, 'utf8'),
    cipher.final(),
  ]);

  const authTag = cipher.getAuthTag();

  const payload = Buffer.concat([iv, authTag, ciphertext]);

  return payload.toString('base64');
}

/**
 * Decrypts a string produced by encrypt(). Throws if the payload has
 * been tampered with (GCM auth tag mismatch) or is malformed.
 */
export function decrypt(encoded: string): string {
  if (typeof encoded !== 'string' || encoded.length === 0) {
    throw new Error('decrypt() requires a non-empty string.');
  }

  const key = getEncryptionKey();
  const payload = Buffer.from(encoded, 'base64');

  if (payload.length < IV_LENGTH + AUTH_TAG_LENGTH) {
    throw new Error('Encrypted payload is malformed or truncated.');
  }

  const iv = payload.subarray(0, IV_LENGTH);
  const authTag = payload.subarray(IV_LENGTH, IV_LENGTH + AUTH_TAG_LENGTH);
  const ciphertext = payload.subarray(IV_LENGTH + AUTH_TAG_LENGTH);

  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);

  try {
    const plaintext = Buffer.concat([
      decipher.update(ciphertext),
      decipher.final(),
    ]);
    return plaintext.toString('utf8');
  } catch (err) {
    throw new Error(
      'Failed to decrypt payload: data may be corrupted or tampered with.'
    );
  }
}

/**
 * One-way hash for values we need to compare but never reveal again
 * (e.g. API tokens — we store the hash and compare hashes on auth).
 */
export function sha256Hex(value: string): string {
  return crypto.createHash('sha256').update(value, 'utf8').digest('hex');
}

/**
 * Timing-safe comparison for secrets (avoids timing attacks on token checks).
 */
export function timingSafeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');

  if (bufA.length !== bufB.length) return false;

  return crypto.timingSafeEqual(bufA, bufB);
}
