import { headers } from 'next/headers';
import { NextResponse } from 'next/server';

/**
 * Reads the verified userId that middleware.ts attached to the request.
 * Throws a structured 401 response if absent — this should be unreachable
 * for any route not in PUBLIC_API_PREFIXES, since middleware already
 * rejects unauthenticated requests, but we defend in depth here in case
 * a route handler is ever invoked outside the normal middleware chain
 * (e.g. direct testing).
 */
export function getUserIdOrThrow(): string {
  const userId = headers().get('x-user-id');

  if (!userId) {
    throw new UnauthorizedError();
  }

  return userId;
}

export class UnauthorizedError extends Error {
  constructor() {
    super('Unauthorized');
    this.name = 'UnauthorizedError';
  }
}

export function unauthorizedResponse() {
  return NextResponse.json(
    { error: 'Unauthorized', message: 'A valid session is required.' },
    { status: 401 }
  );
}