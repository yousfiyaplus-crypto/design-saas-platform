import { z } from 'zod';

/**
 * Accepts either a reference to an existing Component (by id, which also
 * implies a projectId lookup) OR raw code supplied directly. Exactly one
 * of `componentId` or `code` must be present — enforced via refine().
 */
export const DeployRequestSchema = z
  .object({
    projectId: z.string().uuid('projectId must be a valid UUID.'),
    componentId: z.string().uuid('componentId must be a valid UUID.').optional(),
    code: z
      .string()
      .min(1, 'code cannot be empty.')
      .max(200_000, 'code exceeds maximum allowed size.')
      .optional(),
    projectName: z
      .string()
      .min(3, 'projectName must be at least 3 characters.')
      .max(52, 'projectName must be under 52 characters.')
      .regex(
        /^[a-z0-9-]+$/,
        'projectName may only contain lowercase letters, numbers, and hyphens.'
      )
      .optional(),
    target: z.enum(['production', 'preview']).default('preview'),
  })
  .refine((data) => Boolean(data.componentId) !== Boolean(data.code) ? true : Boolean(data.componentId) || Boolean(data.code), {
    message: 'Provide either componentId or code, not neither.',
  })
  .refine((data) => !(data.componentId && data.code), {
    message: 'Provide only one of componentId or code, not both.',
  });

export type DeployRequest = z.infer<typeof DeployRequestSchema>;
