import { z } from 'zod';

export const FrameworkEnum = z.enum(['react', 'vue']);

export const DesignTokensSchema = z
  .object({
    colors: z
      .object({
        primary: z.string().optional(),
        secondary: z.string().optional(),
        accent: z.string().optional(),
        background: z.string().optional(),
        text: z.string().optional(),
      })
      .partial()
      .optional(),
    fonts: z
      .object({
        heading: z.string().optional(),
        body: z.string().optional(),
      })
      .partial()
      .optional(),
    radii: z
      .object({
        sm: z.string().optional(),
        md: z.string().optional(),
        lg: z.string().optional(),
        full: z.string().optional(),
      })
      .partial()
      .optional(),
  })
  .optional();

export const GenerateRequestSchema = z.object({
  prompt: z
    .string()
    .min(10, 'Prompt must be at least 10 characters.')
    .max(4000, 'Prompt must be under 4000 characters.'),
  framework: FrameworkEnum.default('react'),
  designTokens: DesignTokensSchema,
  projectId: z.string().uuid('projectId must be a valid UUID.'),
});

export type GenerateRequest = z.infer<typeof GenerateRequestSchema>;
export type DesignTokens = z.infer<typeof DesignTokensSchema>;

/**
 * Shape we force OpenAI to return via response_format: json_object.
 * We validate the model's output against this too — never trust an
 * LLM's structured output blindly, even with json_object mode.
 */
export const GeneratedComponentSchema = z.object({
  code: z.string().min(1, 'Generated code cannot be empty.'),
  explanation: z.string().min(1, 'Explanation cannot be empty.'),
});

export type GeneratedComponent = z.infer<typeof GeneratedComponentSchema>;
