import { z } from 'zod';

export const ExtractTokensRequestSchema = z.object({
  url: z
    .string()
    .url('Must be a valid URL.')
    .max(2048, 'URL is too long.'),
  projectId: z.string().uuid('projectId must be a valid UUID.'),
});

export type ExtractTokensRequest = z.infer<typeof ExtractTokensRequestSchema>;
