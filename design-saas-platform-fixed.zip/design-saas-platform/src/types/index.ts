// Shared TypeScript types used across the app. Currently empty — add
// cross-cutting types here as the codebase grows (most types today live
// next to their Zod schemas in src/lib/validators/*).
export {};
